package com.example.petbioapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class BioActivity extends AppCompatActivity {
    private ImageView petImageView;
    private TextView petName;
    private TextView petBio;
    private Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio);

        petImageView = (ImageView) findViewById(R.id.petimageView);
        petName = (TextView) findViewById(R.id.nameID);
        petBio = (TextView) findViewById(R.id.bioTextID);

        extras = getIntent().getExtras();

        if (extras != null) {
            String name = extras.getString("name");
            String bio = extras.getString("bio");

            setUp(name, bio);
        }


    }

    public void setUp(String name, String bio) {

        if (name.equals("Jack")){
            petImageView.setImageDrawable(getResources().getDrawable(R.drawable.dog));
            petName.setText(name);
            petBio.setText(bio);

        } else if (name.equals("Jet")) {
            petImageView.setImageDrawable(getResources().getDrawable(R.drawable.cat));
            petName.setText(name);
            petBio.setText(bio);
        }
    }
}
